<?php
$x = readline();
$y = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
echo $y[$x-1]."\n";
?>