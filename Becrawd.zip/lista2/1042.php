<?php
$a = explode(' ', readline());

$b[0] = $a[0];
$b[1] = $a[1];
$b[2] = $a[2];
sort($a);
echo "$a[0]\n"."$a[1]\n"."$a[2]\n"."\n"."$b[0]\n"."$b[1]\n"."$b[2]\n";
?>
